package com.serviceengeneering.lvaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LvaserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
